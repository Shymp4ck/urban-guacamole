#!/bin/sh

set -e

brew install chibi-scheme gauche guile
cargo install stak
