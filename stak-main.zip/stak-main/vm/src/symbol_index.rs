#[cfg(test)]
pub const FALSE: u64 = 0;
#[cfg(test)]
pub const TRUE: u64 = 1;
#[cfg(test)]
pub const NULL: u64 = 2;
pub const RIB: u64 = 3;
#[cfg(test)]
pub const OTHER: u64 = 4;
