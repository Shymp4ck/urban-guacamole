// TODO Decrease this. 😭
pub const DEFAULT_HEAP_SIZE: usize = 1 << 22;
