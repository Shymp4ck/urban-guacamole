require "aruba/cucumber"

Aruba.configure do |config|
  config.exit_timeout = 120
end
